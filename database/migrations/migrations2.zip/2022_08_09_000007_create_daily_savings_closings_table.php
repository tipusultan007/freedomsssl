<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('daily_savings_closings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('daily_savings_id');
            $table->integer('total_deposit');
            $table->integer('total_withdraw');
            $table->integer('balance');
            $table->integer('interest')->nullable();
            $table->foreignId('closing_by');
            $table->date('date');
            $table->integer('closing_fee');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('daily_savings_closings');
    }
};
