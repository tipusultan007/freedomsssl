<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('adjust_amounts', function (Blueprint $table) {
            $table
                ->foreign('loan_id')
                ->references('id')
                ->on('daily_loans')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('daily_loan_id')
                ->references('id')
                ->on('daily_loans')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('added_by')
                ->references('id')
                ->on('users')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('adjust_amounts', function (Blueprint $table) {
            $table->dropForeign(['loan_id']);
            $table->dropForeign(['daily_loan_id']);
            $table->dropForeign(['added_by']);
        });
    }
};
