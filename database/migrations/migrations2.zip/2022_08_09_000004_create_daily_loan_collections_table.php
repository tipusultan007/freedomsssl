<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('daily_loan_collections', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('daily_loan_id');
            $table->integer('loan_installment');
            $table->integer('loan_late_fee')->nullable();
            $table->integer('loan_other_fee')->nullable();
            $table->string('loan_note')->nullable();
            $table->integer('loan_balance');
            $table->foreignId('collector_id');
            $table->date('date');
            $table->foreignId('user_id');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('daily_loan_collections');
    }
};
