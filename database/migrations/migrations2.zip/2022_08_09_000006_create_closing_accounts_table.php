<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('closing_accounts', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('user_id');
            $table->string('type')->nullable();
            $table->integer('deposit')->nullable();
            $table->integer('Withdraw')->nullable();
            $table->integer('remain')->nullable();
            $table->integer('profit')->nullable();
            $table->integer('service_charge')->nullable();
            $table->integer('total')->nullable();
            $table->date('date');
            $table->foreignId('created_by');
            $table->foreignId('daily_savings_id')->nullable();
            $table->foreignId('dps_id')->nullable();
            $table->foreignId('special_dps_id')->nullable();
            $table->foreignId('fdr_id')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('closing_accounts');
    }
};
