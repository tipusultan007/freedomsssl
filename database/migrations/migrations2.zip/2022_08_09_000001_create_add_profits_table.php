<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('add_profits', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->foreignId('daily_savings_id');
            $table->foreignId('user_id');
            $table->string('account_no');
            $table->integer('profit');
            $table->integer('before_profit');
            $table->integer('after_profit');
            $table->date('date');
            $table->string('duration');
            $table->foreignId('created_by');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('add_profits');
    }
};
