<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('dps_installments', function (Blueprint $table) {
            $table
                ->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('dps_id')
                ->references('id')
                ->on('dps')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('collector_id')
                ->references('id')
                ->on('users')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('dps_loan_id')
                ->references('id')
                ->on('dps_loans')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('dps_installments', function (Blueprint $table) {
            $table->dropForeign(['user_id']);
            $table->dropForeign(['dps_id']);
            $table->dropForeign(['collector_id']);
            $table->dropForeign(['dps_loan_id']);
        });
    }
};
