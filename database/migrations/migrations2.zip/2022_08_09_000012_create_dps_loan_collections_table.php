<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dps_loan_collections', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('user_id');
            $table->foreignId('dps_loan_id');
            $table->foreignId('collector_id');
            $table->foreignId('dps_installment_id');
            $table->string('trx_id');
            $table->integer('loan_installment');
            $table->integer('balance');
            $table->integer('interest')->nullable();
            $table->date('date');
            $table->string('receipt_no')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dps_loan_collections');
    }
};
