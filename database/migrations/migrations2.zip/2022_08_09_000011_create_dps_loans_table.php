<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dps_loans', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('user_id');
            $table->integer('loan_amount');
            $table->float('interest1');
            $table->float('interest2')->nullable();
            $table->date('application_date');
            $table->foreignId('approved_by');
            $table->date('opening_date')->nullable();
            $table->date('commencement');
            $table->string('status');
            $table->foreignId('created_by');
            $table
                ->integer('total_paid')
                ->default(0)
                ->nullable();
            $table->integer('remain_loan')->nullable();
            $table->integer('installment');

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dps_loans');
    }
};
