<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('adjust_amounts', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->foreignId('loan_id');
            $table->unsignedBigInteger('daily_loan_id');
            $table->integer('adjust_amount');
            $table->integer('before_adjust');
            $table->integer('after_adjust');
            $table->date('date');
            $table->foreignId('added_by');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('adjust_amounts');
    }
};
