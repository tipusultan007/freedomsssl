<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fdr_deposits', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('fdr_id');
            $table->foreignId('user_id');
            $table->integer('amount');
            $table->foreignId('fdr_package_id');
            $table->date('date');
            $table->date('commencement');
            $table->integer('balance');
            $table->integer('profit');
            $table->foreignId('created_by');
            $table->string('note')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fdr_deposits');
    }
};
