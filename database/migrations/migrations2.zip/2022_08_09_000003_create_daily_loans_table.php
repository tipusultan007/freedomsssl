<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('daily_loans', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->foreignId('user_id');
            $table->foreignId('package_id');
            $table
                ->integer('per_installment')
                ->default(11)
                ->nullable();
            $table->date('opening_date');
            $table->integer('interest');
            $table->integer('adjusted_amount')->nullable();
            $table->date('commencement');
            $table->integer('loan_amount');
            $table->date('application_date')->nullable();
            $table->foreignId('created_by');
            $table->foreignId('approved_by');
            $table->string('status');

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('daily_loans');
    }
};
