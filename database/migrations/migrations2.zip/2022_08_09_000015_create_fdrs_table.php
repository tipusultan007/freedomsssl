<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fdrs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('user_id');
            $table->foreignId('fdr_package_id');
            $table->float('duration');
            $table->date('date');
            $table->integer('fdr_amount')->nullable();
            $table->date('deposit_date');
            $table->date('commencement');
            $table->string('note')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fdrs');
    }
};
