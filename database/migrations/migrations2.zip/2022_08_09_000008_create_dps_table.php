<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dps', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('user_id');
            $table->foreignId('dps_package_id');
            $table->integer('balance');
            $table->string('status');
            $table->foreignId('created_by');
            $table->date('opening_date');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dps');
    }
};
