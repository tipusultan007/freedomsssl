<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dps_installments', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('user_id');
            $table->foreignId('dps_id')->nullable();
            $table->foreignId('collector_id');
            $table->foreignId('dps_loan_id')->nullable();
            $table->integer('dps_amount')->nullable();
            $table->integer('dps_balance')->nullable();
            $table->string('receipt_no')->nullable();
            $table->integer('late_fee')->nullable();
            $table->integer('other_fee')->nullable();
            $table->integer('grace')->nullable();
            $table->integer('advance')->nullable();
            $table->integer('loan_installment')->nullable();
            $table->integer('interest')->nullable();
            $table->string('trx_id');
            $table->integer('loan_balance')->nullable();
            $table->integer('total');
            $table->integer('due')->nullable();
            $table->integer('due_return')->nullable();
            $table->date('date');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dps_installments');
    }
};
