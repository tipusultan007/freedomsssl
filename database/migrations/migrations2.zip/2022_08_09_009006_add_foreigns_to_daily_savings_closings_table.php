<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('daily_savings_closings', function (Blueprint $table) {
            $table
                ->foreign('daily_savings_id')
                ->references('id')
                ->on('daily_savings')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('closing_by')
                ->references('id')
                ->on('users')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('daily_savings_closings', function (Blueprint $table) {
            $table->dropForeign(['daily_savings_id']);
            $table->dropForeign(['closing_by']);
        });
    }
};
