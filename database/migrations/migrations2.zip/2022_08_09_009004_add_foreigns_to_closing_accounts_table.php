<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('closing_accounts', function (Blueprint $table) {
            $table
                ->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('created_by')
                ->references('id')
                ->on('users')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('daily_savings_id')
                ->references('id')
                ->on('daily_savings')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('dps_id')
                ->references('id')
                ->on('dps')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('special_dps_id')
                ->references('id')
                ->on('special_dps')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('fdr_id')
                ->references('id')
                ->on('fdrs')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('closing_accounts', function (Blueprint $table) {
            $table->dropForeign(['user_id']);
            $table->dropForeign(['created_by']);
            $table->dropForeign(['daily_savings_id']);
            $table->dropForeign(['dps_id']);
            $table->dropForeign(['special_dps_id']);
            $table->dropForeign(['fdr_id']);
        });
    }
};
