<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('daily_savings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no', 20);
            $table->foreignId('user_id');
            $table->date('opening_date');
            $table->foreignId('introducer_id');
            $table->string('status', 15);
            $table->integer('created_by');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('daily_savings');
    }
};
