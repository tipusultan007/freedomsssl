<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('special_dps_package_values', function (
            Blueprint $table
        ) {
            $table
                ->foreign('special_dps_package_id')
                ->references('id')
                ->on('special_dps_packages')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('special_dps_package_values', function (
            Blueprint $table
        ) {
            $table->dropForeign(['special_dps_package_id']);
        });
    }
};
