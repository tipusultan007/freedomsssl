<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('dps_package_values', function (Blueprint $table) {
            $table
                ->foreign('dps_package_id')
                ->references('id')
                ->on('dps_packages')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('dps_package_values', function (Blueprint $table) {
            $table->dropForeign(['dps_package_id']);
        });
    }
};
