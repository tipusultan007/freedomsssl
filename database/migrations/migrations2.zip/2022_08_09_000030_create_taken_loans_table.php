<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('taken_loans', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('user_id');
            $table->integer('loan_amount');
            $table->integer('before_loan');
            $table->integer('after_loan');
            $table->float('interest1');
            $table->float('interest2')->nullable();
            $table->integer('upto_amount')->nullable();
            $table->date('date');
            $table->date('commencement');
            $table->foreignId('created_by');
            $table->foreignId('dps_loan_id');
            $table->integer('installment');

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('taken_loans');
    }
};
