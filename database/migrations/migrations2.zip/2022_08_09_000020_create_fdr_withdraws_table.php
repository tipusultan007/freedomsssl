<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fdr_withdraws', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('user_id');
            $table->foreignId('fdr_id');
            $table->date('date');
            $table->foreignId('fdr_deposit_id');
            $table->integer('withdraw_amount');
            $table->string('note')->nullable();
            $table->foreignId('created_by');
            $table->integer('balance');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fdr_withdraws');
    }
};
