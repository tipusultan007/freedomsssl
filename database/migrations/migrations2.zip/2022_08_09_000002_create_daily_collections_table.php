<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('daily_collections', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('user_id');
            $table->foreignId('collector_id');
            $table->integer('saving_amount')->nullable();
            $table->string('saving_type')->nullable();
            $table->integer('late_fee')->nullable();
            $table->integer('other_fee')->nullable();
            $table->integer('loan_installment')->nullable();
            $table->integer('loan_late_fee')->nullable();
            $table->integer('loan_other_fee')->nullable();
            $table->string('saving_note')->nullable();
            $table->string('loan_note')->nullable();
            $table->foreignId('daily_savings_id')->nullable();
            $table->foreignId('daily_loan_id')->nullable();
            $table->integer('savings_balance')->nullable();
            $table->integer('loan_balance')->nullable();
            $table->date('date');

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('daily_collections');
    }
};
