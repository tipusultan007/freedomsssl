<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('fdr_deposits', function (Blueprint $table) {
            $table
                ->foreign('fdr_id')
                ->references('id')
                ->on('fdrs')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('user_id')
                ->references('id')
                ->on('users')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('fdr_package_id')
                ->references('id')
                ->on('fdr_packages')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');

            $table
                ->foreign('created_by')
                ->references('id')
                ->on('users')
                ->onUpdate('CASCADE')
                ->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('fdr_deposits', function (Blueprint $table) {
            $table->dropForeign(['fdr_id']);
            $table->dropForeign(['user_id']);
            $table->dropForeign(['fdr_package_id']);
            $table->dropForeign(['created_by']);
        });
    }
};
