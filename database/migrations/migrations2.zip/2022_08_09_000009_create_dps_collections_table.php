<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dps_collections', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('account_no');
            $table->foreignId('user_id');
            $table->foreignId('dps_id');
            $table->integer('dps_amount');
            $table->integer('balance');
            $table->string('receipt_no')->nullable();
            $table->integer('late_fee')->nullable();
            $table->integer('other_fee')->nullable();
            $table->integer('advance')->nullable();
            $table->enum('month', [
                'January',
                'February',
                'March',
                'April',
                'May',
                'June',
                'July',
                'August',
                'September',
                'October',
                'November',
                'December',
            ]);
            $table->year('year');
            $table->string('trx_id');
            $table->date('date');
            $table->foreignId('collector_id');
            $table->foreignId('dps_installment_id');

            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dps_collections');
    }
};
